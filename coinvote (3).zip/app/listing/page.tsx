import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "List Your Coin, NFT, Airdrop or ICO | Coinvote.cash",
  description: "List your cryptocurrency project on Coinvote.cash to gain visibility and attract voters.",
}

export default function ListingPage() {
  return (
    <div className="min-h-screen bg-moon-night text-white">
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-center">List Your Project on Coinvote.cash</h1>
        <p className="text-gray-300 text-center max-w-3xl mx-auto mb-12">
          Get your cryptocurrency, NFT collection, airdrop, or ICO in front of thousands of potential investors. Choose
          the listing option that works best for your project.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {/* Free Listing */}
          <div className="bg-[#0D1217] rounded-lg border border-gray-800 overflow-hidden hover:border-coin-yellow transition-colors">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-2">Free Listing</h2>
              <div className="text-3xl font-bold mb-4 text-coin-yellow">$0</div>
              <p className="text-gray-300 mb-6">Basic listing for new projects with standard visibility.</p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Standard position in listings</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Basic project information</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Community voting enabled</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Manual review (1-3 days)</span>
                </li>
              </ul>
              <Link href="/listing/free">
                <Button className="w-full bg-coin-green hover:bg-coin-green/90">List for Free</Button>
              </Link>
            </div>
          </div>

          {/* Premium Listing */}
          <div className="bg-[#0D1217] rounded-lg border-2 border-coin-yellow overflow-hidden transform md:scale-105 z-10 shadow-xl">
            <div className="bg-coin-yellow text-black text-center py-1 font-semibold">MOST POPULAR</div>
            <div className="p-6">
              <h2 className="text-xl font-bold mb-2">Premium Listing</h2>
              <div className="text-3xl font-bold mb-4 text-coin-yellow">$199</div>
              <p className="text-gray-300 mb-6">Enhanced visibility with priority placement and additional features.</p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Priority position in listings</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Enhanced project profile</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Social media promotion</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Expedited review (24 hours)</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Featured for 7 days</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Detailed analytics</span>
                </li>
              </ul>
              <Link href="/listing/premium">
                <Button className="w-full bg-coin-yellow text-black hover:bg-coin-yellow/90">Get Premium</Button>
              </Link>
            </div>
          </div>

          {/* Promoted Listing */}
          <div className="bg-[#0D1217] rounded-lg border border-gray-800 overflow-hidden hover:border-coin-yellow transition-colors">
            <div className="p-6">
              <h2 className="text-xl font-bold mb-2">Promoted Listing</h2>
              <div className="text-3xl font-bold mb-4 text-coin-yellow">$499</div>
              <p className="text-gray-300 mb-6">Maximum exposure with top placement and comprehensive promotion.</p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Top position in listings</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Premium project profile</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Banner promotion</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Immediate review</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Featured for 30 days</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Advanced analytics</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-coin-green mr-2 mt-0.5" />
                  <span>Newsletter feature</span>
                </li>
              </ul>
              <Link href="/listing/promoted">
                <Button className="w-full bg-coin-green hover:bg-coin-green/90">Get Promoted</Button>
              </Link>
            </div>
          </div>
        </div>

        <div className="bg-[#0D1217] rounded-lg border border-gray-800 p-8 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-4 text-center">Why List on Coinvote.cash?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-coin-yellow mb-2">870K+</div>
              <p className="text-gray-300">Active Users</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-coin-yellow mb-2">2.5M+</div>
              <p className="text-gray-300">Monthly Page Views</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-coin-yellow mb-2">15K+</div>
              <p className="text-gray-300">Listed Projects</p>
            </div>
          </div>
          <p className="text-gray-300 text-center mb-6">
            Join thousands of successful projects that have gained visibility and traction through Coinvote.cash. Our
            platform connects you with active crypto enthusiasts looking for promising new investments.
          </p>
          <div className="flex justify-center">
            <Button className="bg-coin-yellow text-black hover:bg-coin-yellow/90">Contact Our Team</Button>
          </div>
        </div>
      </div>
    </div>
  )
}

