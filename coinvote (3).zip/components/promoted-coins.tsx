"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import { getCoins, voteCoin } from "@/lib/actions"
import { getLogoUrl, formatNumber, timeSinceLaunch } from "@/lib/api"

interface Coin {
  id: string
  name: string
  symbol: string
  price: number
  change: number
  marketCap: number
  launchDate: string
  votes: number
}

// For demo purposes, we'll mark some coins as verified and promoted
const verifiedSymbols = ["BTC", "ETH", "BNB", "SOL", "ADA"]

export default function PromotedCoins() {
  const [coins, setCoins] = useState<Coin[]>([])
  const [loading, setLoading] = useState(true)
  const [voting, setVoting] = useState<Record<string, boolean>>({})

  useEffect(() => {
    async function fetchCoins() {
      setLoading(true)
      const result = await getCoins()
      if (result.success) {
        // Get top 5 coins by market cap for promoted section
        const promotedCoins = result.data
          .sort((a, b) => b.marketCap - a.marketCap)
          .slice(0, 5)
          .map((coin) => ({
            ...coin,
            verified: verifiedSymbols.includes(coin.symbol),
          }))

        setCoins(promotedCoins)
      }
      setLoading(false)
    }

    fetchCoins()
  }, [])

  const handleVote = async (id: string) => {
    setVoting((prev) => ({ ...prev, [id]: true }))
    await voteCoin(id)

    // Update the local state to reflect the vote
    setCoins((prev) => prev.map((coin) => (coin.id === id ? { ...coin, votes: coin.votes + 1 } : coin)))

    setVoting((prev) => ({ ...prev, [id]: false }))
  }

  if (loading) {
    return (
      <div className="bg-[#0a0a0a] rounded-lg border border-gray-800 p-8 flex justify-center items-center">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-yellow-400"></div>
      </div>
    )
  }

  return (
    <div className="bg-[#0a0a0a] rounded-lg border border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-yellow-400"></span>
          <h3 className="font-medium">Promoted Coins</h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center text-xs text-gray-400">
            <span className="h-2 w-2 rounded-full bg-blue-400 mr-1"></span>
            Verified Coins
          </span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-left text-xs text-gray-400 border-b border-gray-800">
              <th className="px-4 py-3 w-12">#</th>
              <th className="px-4 py-3">Coin</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">24h</th>
              <th className="px-4 py-3">Market Cap</th>
              <th className="px-4 py-3">Since Launch</th>
              <th className="px-4 py-3">Vote</th>
            </tr>
          </thead>
          <tbody>
            {coins.map((coin, index) => (
              <tr key={coin.id} className="border-b border-gray-800 hover:bg-gray-900/50">
                <td className="px-4 py-3 text-sm">{index + 1}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <Image
                      src={getLogoUrl(coin.symbol) || "/placeholder.svg"}
                      alt={coin.name}
                      width={24}
                      height={24}
                      className="rounded-full"
                      onError={(e) => {
                        // Fallback to placeholder if logo not found
                        ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=24&width=24"
                      }}
                    />
                    <div className="flex items-center">
                      <Link href={`/coins/${coin.id}`} className="font-medium hover:text-yellow-400">
                        {coin.name}
                      </Link>
                      {coin.verified && (
                        <span className="ml-1 bg-blue-500 rounded-full p-0.5 flex items-center justify-center">
                          <Check className="h-2 w-2 text-white" />
                        </span>
                      )}
                      <div className="text-xs text-gray-400 ml-1">{coin.symbol}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 font-medium">
                  ${coin.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 })}
                </td>
                <td className={`px-4 py-3 ${coin.change >= 0 ? "text-green-500" : "text-red-500"}`}>
                  {coin.change >= 0 ? "+" : ""}
                  {coin.change.toFixed(2)}%
                </td>
                <td className="px-4 py-3">{formatNumber(coin.marketCap)}</td>
                <td className="px-4 py-3 text-sm">{timeSinceLaunch(coin.launchDate)}</td>
                <td className="px-4 py-3">
                  <Button
                    onClick={() => handleVote(coin.id)}
                    size="sm"
                    className="bg-yellow-400 text-black hover:bg-yellow-500 w-16"
                    disabled={voting[coin.id]}
                  >
                    {voting[coin.id] ? "..." : "Vote"}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

