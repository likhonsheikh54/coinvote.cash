"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, ChevronDown, ChevronRight, Search } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface NavItem {
  title: string
  href: string
  children?: NavItem[]
  highlight?: boolean
}

const navItems: NavItem[] = [
  {
    title: "Listing",
    href: "/listing",
    highlight: true,
    children: [
      { title: "Free", href: "/listing/free" },
      { title: "Premium", href: "/listing/premium" },
      { title: "Promoted", href: "/listing/promoted" },
    ],
  },
  {
    title: "Coin",
    href: "/coins",
    children: [
      { title: "All Coins", href: "/coins" },
      { title: "Recently Listed", href: "/coins/recently-listed" },
      { title: "Trending", href: "/coins/trending" },
      { title: "Most Voted", href: "/coins/most-voted" },
      { title: "Presales", href: "/coins/presales" },
    ],
  },
  {
    title: "NFT",
    href: "/nft",
    children: [
      { title: "All NFTs", href: "/nft" },
      { title: "Collections", href: "/nft/collections" },
      { title: "Trending", href: "/nft/trending" },
    ],
  },
  {
    title: "Airdrop",
    href: "/airdrops",
    children: [
      { title: "All Airdrops", href: "/airdrops" },
      { title: "Active", href: "/airdrops/active" },
      { title: "Upcoming", href: "/airdrops/upcoming" },
      { title: "Ended", href: "/airdrops/ended" },
    ],
  },
  {
    title: "ICO",
    href: "/icos",
    children: [
      { title: "All ICOs", href: "/icos" },
      { title: "Active", href: "/icos/active" },
      { title: "Upcoming", href: "/icos/upcoming" },
      { title: "Ended", href: "/icos/ended" },
    ],
  },
  {
    title: "Article",
    href: "/articles",
  },
  {
    title: "Other",
    href: "#",
    children: [
      { title: "Tools", href: "/tools" },
      { title: "Events", href: "/events" },
      { title: "DEX Explorer", href: "/dex" },
      { title: "Meme Explorer", href: "/meme-explorer" },
      { title: "Top Traders", href: "/top-traders" },
    ],
  },
  { title: "Advertising", href: "/advertising" },
  { title: "Partners", href: "/partners" },
]

export default function MobileNavigation() {
  const [isOpen, setIsOpen] = useState(false)
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({})

  const toggleMenu = () => {
    setIsOpen(!isOpen)
  }

  const toggleItem = (title: string) => {
    setExpandedItems((prev) => ({
      ...prev,
      [title]: !prev[title],
    }))
  }

  return (
    <div className="md:hidden">
      <button onClick={toggleMenu} className="p-2 text-white focus:outline-none" aria-label="Toggle menu">
        {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 bg-moon-night overflow-y-auto">
          <div className="flex justify-between items-center p-4 border-b border-gray-800">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/OIP%20%2833%29.jpg-AQC4I7btYIFWbNLFF4szUc2IRlblnc.jpeg"
                alt="Coinvote"
                width={32}
                height={32}
              />
              <span className="font-bold text-xl text-coin-yellow">coinvote</span>
            </Link>
            <button onClick={toggleMenu} className="p-2 text-white focus:outline-none" aria-label="Close menu">
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="p-4 border-b border-gray-800">
            <div className="flex gap-2 mb-4">
              <Button
                variant="outline"
                className="flex-1 border-coin-yellow text-coin-yellow hover:bg-coin-yellow hover:text-black"
              >
                Log In
              </Button>
              <Button className="flex-1 bg-coin-green text-white hover:bg-coin-green/90">Sign Up</Button>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search..."
                className="w-full bg-[#1e1e1e] rounded-full pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-coin-yellow"
              />
            </div>
          </div>

          <nav className="p-4">
            <ul className="space-y-4">
              {navItems.map((item) => (
                <li key={item.title} className="border-b border-gray-800 pb-2">
                  {item.children ? (
                    <div>
                      <button
                        onClick={() => toggleItem(item.title)}
                        className={`flex items-center justify-between w-full py-2 ${
                          item.highlight ? "text-coin-green font-semibold" : "text-white"
                        }`}
                      >
                        <span>{item.title}</span>
                        <ChevronDown
                          className={cn("h-5 w-5 transition-transform", expandedItems[item.title] ? "rotate-180" : "")}
                        />
                      </button>
                      {expandedItems[item.title] && (
                        <ul className="pl-4 mt-2 space-y-2">
                          {item.children.map((child) => (
                            <li key={child.title}>
                              <Link
                                href={child.href}
                                className="flex items-center py-2 text-gray-300 hover:text-coin-yellow"
                                onClick={toggleMenu}
                              >
                                <ChevronRight className="h-4 w-4 mr-2" />
                                {child.title}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ) : (
                    <Link
                      href={item.href}
                      className={`block py-2 hover:text-coin-yellow ${
                        item.highlight ? "text-coin-green font-semibold" : "text-white"
                      }`}
                      onClick={toggleMenu}
                    >
                      {item.title}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </nav>
        </div>
      )}
    </div>
  )
}

