"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export default function FeaturedSection() {
  const [activeTab, setActiveTab] = useState("coins")

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Featured Listings</h2>
        <Button
          variant="outline"
          size="sm"
          className="text-coin-yellow border-coin-yellow hover:bg-coin-yellow hover:text-black"
        >
          View All
        </Button>
      </div>

      <Tabs defaultValue="coins" onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="coins" className="data-[state=active]:bg-coin-green data-[state=active]:text-white">
            Coins
          </TabsTrigger>
          <TabsTrigger value="nfts" className="data-[state=active]:bg-coin-green data-[state=active]:text-white">
            NFTs
          </TabsTrigger>
          <TabsTrigger value="airdrops" className="data-[state=active]:bg-coin-green data-[state=active]:text-white">
            Airdrops
          </TabsTrigger>
          <TabsTrigger value="icos" className="data-[state=active]:bg-coin-green data-[state=active]:text-white">
            ICOs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="coins" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((item) => (
              <div
                key={item}
                className="bg-[#0D1217] rounded-lg border border-gray-800 overflow-hidden hover:border-coin-yellow transition-colors"
              >
                <div className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-lg font-bold">
                      C{item}
                    </div>
                    <div>
                      <h3 className="font-medium">Featured Coin {item}</h3>
                      <div className="text-xs text-gray-400">FC{item}</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center mb-3">
                    <div className="text-xs text-gray-400">Price</div>
                    <div className="font-medium">${(0.05 * item).toFixed(2)}</div>
                  </div>
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-xs text-gray-400">24h Change</div>
                    <div className={`text-sm ${item % 2 === 0 ? "text-coin-green" : "text-red-500"}`}>
                      {item % 2 === 0 ? "+" : "-"}
                      {item * 2.5}%
                    </div>
                  </div>
                  <Link href={`/coins/featured-${item}`}>
                    <Button className="w-full bg-coin-yellow text-black hover:bg-coin-yellow/90">View Details</Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-center">
            <Link href="/coins" className="inline-flex items-center text-coin-yellow hover:underline">
              View all coins <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </TabsContent>

        <TabsContent value="nfts" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((item) => (
              <div
                key={item}
                className="bg-[#0D1217] rounded-lg border border-gray-800 overflow-hidden hover:border-coin-yellow transition-colors"
              >
                <div className="aspect-square bg-gray-800 relative">
                  <div className="absolute inset-0 flex items-center justify-center text-2xl font-bold text-gray-600">
                    NFT {item}
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-medium mb-2">NFT Collection {item}</h3>
                  <div className="flex justify-between items-center mb-3">
                    <div className="text-xs text-gray-400">Floor Price</div>
                    <div className="font-medium">{(0.5 * item).toFixed(2)} ETH</div>
                  </div>
                  <Link href={`/nft/collection-${item}`}>
                    <Button className="w-full bg-coin-yellow text-black hover:bg-coin-yellow/90">
                      View Collection
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-center">
            <Link href="/nft" className="inline-flex items-center text-coin-yellow hover:underline">
              View all NFTs <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </TabsContent>

        <TabsContent value="airdrops" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((item) => (
              <div
                key={item}
                className="bg-[#0D1217] rounded-lg border border-gray-800 overflow-hidden hover:border-coin-yellow transition-colors"
              >
                <div className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-lg font-bold">
                      A{item}
                    </div>
                    <div>
                      <h3 className="font-medium">Airdrop {item}</h3>
                      <div className="text-xs text-gray-400">Ends in {item} days</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center mb-3">
                    <div className="text-xs text-gray-400">Reward</div>
                    <div className="font-medium">${(100 * item).toLocaleString()}</div>
                  </div>
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-xs text-gray-400">Participants</div>
                    <div className="text-sm">{(1000 * item).toLocaleString()}</div>
                  </div>
                  <Link href={`/airdrops/${item}`}>
                    <Button className="w-full bg-coin-yellow text-black hover:bg-coin-yellow/90">Participate</Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-center">
            <Link href="/airdrops" className="inline-flex items-center text-coin-yellow hover:underline">
              View all airdrops <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </TabsContent>

        <TabsContent value="icos" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((item) => (
              <div
                key={item}
                className="bg-[#0D1217] rounded-lg border border-gray-800 overflow-hidden hover:border-coin-yellow transition-colors"
              >
                <div className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-lg font-bold">
                      I{item}
                    </div>
                    <div>
                      <h3 className="font-medium">ICO Project {item}</h3>
                      <div className="text-xs text-gray-400">Ends in {item * 5} days</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center mb-3">
                    <div className="text-xs text-gray-400">Hard Cap</div>
                    <div className="font-medium">${(1000000 * item).toLocaleString()}</div>
                  </div>
                  <div className="mb-3">
                    <div className="flex justify-between text-xs mb-1">
                      <span>Progress</span>
                      <span>{item * 20}%</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div className="bg-coin-green h-2 rounded-full" style={{ width: `${item * 20}%` }}></div>
                    </div>
                  </div>
                  <Link href={`/icos/${item}`}>
                    <Button className="w-full bg-coin-yellow text-black hover:bg-coin-yellow/90">View ICO</Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-center">
            <Link href="/icos" className="inline-flex items-center text-coin-yellow hover:underline">
              View all ICOs <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

