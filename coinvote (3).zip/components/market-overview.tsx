"use client"

import { useState, useEffect } from "react"
import { getMarketOverview } from "@/lib/actions"
import { formatNumber } from "@/lib/coingecko-api"

interface MarketData {
  active_cryptocurrencies: number
  markets: number
  total_market_cap: { [key: string]: number }
  total_volume: { [key: string]: number }
  market_cap_percentage: { [key: string]: number }
  market_cap_change_percentage_24h_usd: number
}

export default function MarketOverview() {
  const [marketData, setMarketData] = useState<MarketData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchMarketData() {
      try {
        setLoading(true)
        setError(null)
        const result = await getMarketOverview()
        if (result.success && result.data) {
          // Validate the data structure before setting state
          const data = result.data

          // Create a validated market data object with default values for missing properties
          const validatedData: MarketData = {
            active_cryptocurrencies: data.active_cryptocurrencies || 0,
            markets: data.markets || 0,
            total_market_cap: data.total_market_cap || { usd: 0 },
            total_volume: data.total_volume || { usd: 0 },
            market_cap_percentage: data.market_cap_percentage || { btc: 0, eth: 0 },
            market_cap_change_percentage_24h_usd: data.market_cap_change_percentage_24h_usd || 0,
          }

          setMarketData(validatedData)
        } else {
          setError("Failed to fetch market data")
          console.error("Failed to fetch market data:", result.message || "Unknown error")
        }
      } catch (err) {
        setError("An error occurred while fetching market data")
        console.error("Error in fetchMarketData:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchMarketData()
  }, [])

  if (loading) {
    return (
      <div className="bg-[#0D1217] rounded-lg border border-gray-800 p-4 animate-pulse">
        <div className="h-6 bg-gray-800 rounded w-1/3 mb-4"></div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="h-10 bg-gray-800 rounded"></div>
          <div className="h-10 bg-gray-800 rounded"></div>
          <div className="h-10 bg-gray-800 rounded"></div>
          <div className="h-10 bg-gray-800 rounded"></div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="bg-[#0D1217] rounded-lg border border-gray-800 p-4">
        <div className="text-red-400 text-center">{error}</div>
      </div>
    )
  }

  if (!marketData) {
    return (
      <div className="bg-[#0D1217] rounded-lg border border-gray-800 p-4">
        <div className="text-gray-400 text-center">No market data available</div>
      </div>
    )
  }

  const getChangeColor = (change: number) => {
    return change >= 0 ? "text-coin-green" : "text-red-500"
  }

  // Ensure all properties exist before rendering
  const btcDominance = marketData.market_cap_percentage?.btc || 0
  const ethDominance = marketData.market_cap_percentage?.eth || 0
  const marketCapUsd = marketData.total_market_cap?.usd || 0
  const volumeUsd = marketData.total_volume?.usd || 0
  const marketCapChange = marketData.market_cap_change_percentage_24h_usd || 0

  return (
    <div className="bg-[#0D1217] rounded-lg border border-gray-800 p-4">
      <h2 className="text-lg font-semibold mb-4">Market Overview</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div>
          <div className="text-xs text-gray-400">Cryptocurrencies</div>
          <div className="font-medium">{marketData.active_cryptocurrencies?.toLocaleString() || "0"}</div>
        </div>
        <div>
          <div className="text-xs text-gray-400">Markets</div>
          <div className="font-medium">{marketData.markets?.toLocaleString() || "0"}</div>
        </div>
        <div>
          <div className="text-xs text-gray-400">Market Cap</div>
          <div className="font-medium">{formatNumber(marketCapUsd)}</div>
        </div>
        <div>
          <div className="text-xs text-gray-400">24h Volume</div>
          <div className="font-medium">{formatNumber(volumeUsd)}</div>
        </div>
        <div>
          <div className="text-xs text-gray-400">BTC Dominance</div>
          <div className="font-medium">{btcDominance.toFixed(1)}%</div>
        </div>
        <div>
          <div className="text-xs text-gray-400">ETH Dominance</div>
          <div className="font-medium">{ethDominance.toFixed(1)}%</div>
        </div>
        <div>
          <div className="text-xs text-gray-400">Market Cap Change (24h)</div>
          <div className={`font-medium ${getChangeColor(marketCapChange)}`}>
            {marketCapChange >= 0 ? "+" : ""}
            {marketCapChange.toFixed(2)}%
          </div>
        </div>
      </div>
    </div>
  )
}

