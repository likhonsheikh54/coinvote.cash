"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

export default function MobileAppBanner() {
  const [isVisible, setIsVisible] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    // Check if user is on mobile device
    const checkMobile = () => {
      const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera
      const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)
      setIsMobile(isMobileDevice)
    }

    // Check if banner has been dismissed before
    const checkDismissed = () => {
      const dismissed = localStorage.getItem("app_banner_dismissed")
      return dismissed === "true"
    }

    checkMobile()

    // Only show banner on mobile devices and if not dismissed before
    if (isMobile && !checkDismissed()) {
      setIsVisible(true)
    }
  }, [isMobile])

  const dismissBanner = () => {
    setIsVisible(false)
    localStorage.setItem("app_banner_dismissed", "true")
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-[#0D1217] border-t border-gray-800 p-4 z-50">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_3099-myVKXdeyH7u4SPrSdLNXdYsSnrqAyO.png"
            alt="Coinvote App"
            width={40}
            height={40}
            className="rounded-lg"
          />
          <div>
            <div className="font-bold">Coinvote App</div>
            <div className="text-xs text-gray-400">Track crypto on the go</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button className="bg-[#FFDD33] text-black hover:bg-[#FFDD33]/90">Download</Button>
          <button onClick={dismissBanner} className="p-2 text-gray-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  )
}

