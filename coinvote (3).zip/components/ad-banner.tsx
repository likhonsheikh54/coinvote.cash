export default function AdBanner() {
  return (
    <div className="w-full bg-gradient-to-r from-[#0D1217] to-[#1a1f25] rounded-lg p-4 mb-6 relative overflow-hidden border border-gray-800">
      <div className="absolute top-0 right-0 bottom-0 left-0 bg-[url('/placeholder.svg?height=100&width=400')] bg-no-repeat bg-right-bottom opacity-20"></div>
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between">
        <div>
          <h3 className="text-xl font-bold text-white mb-2">DAWGZ AI - The Future of Meme Coins</h3>
          <p className="text-gray-300 mb-4 md:mb-0">Join the presale now and get 20% bonus! Limited time offer.</p>
        </div>
        <a
          href="#"
          className="bg-coin-yellow hover:bg-coin-yellow/90 text-black font-medium px-6 py-2 rounded-full transition-colors"
        >
          Buy Now
        </a>
      </div>
    </div>
  )
}

