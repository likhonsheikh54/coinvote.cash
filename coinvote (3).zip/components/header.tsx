import Link from "next/link"
import Image from "next/image"
import { Search, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import MainNavigation from "@/components/main-navigation"
import MobileNavigation from "@/components/mobile-navigation"

export default function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-gray-800 bg-moon-night">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/OIP%20%2833%29.jpg-AQC4I7btYIFWbNLFF4szUc2IRlblnc.jpeg"
              alt="Coinvote"
              width={32}
              height={32}
            />
            <span className="font-bold text-xl text-coin-yellow">coinvote</span>
          </Link>

          <MainNavigation />
        </div>

        <div className="flex items-center gap-4">
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search..."
              className="bg-[#1e1e1e] rounded-full pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-coin-yellow w-64"
            />
          </div>

          <Link href="/notifications" className="text-gray-400 hover:text-white">
            <Bell className="h-5 w-5" />
          </Link>

          <div className="hidden md:flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-coin-yellow text-coin-yellow hover:bg-coin-yellow hover:text-black"
            >
              Log In
            </Button>
            <Button size="sm" className="bg-coin-green text-white hover:bg-coin-green/90">
              Sign Up
            </Button>
          </div>

          <MobileNavigation />
        </div>
      </div>
    </header>
  )
}

