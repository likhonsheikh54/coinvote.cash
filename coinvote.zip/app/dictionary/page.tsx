import DictionaryClientPage from "./DictionaryClientPage"

export const metadata = {
  title: "Crypto Dictionary | CoinVote",
  description: "Learn about cryptocurrency terms and definitions",
}

export default function DictionaryPage() {
  return <DictionaryClientPage />
}

