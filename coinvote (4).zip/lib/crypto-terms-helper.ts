import cryptoTermsData from "./crypto-terms.json"

export { cryptoTermsData }
export default cryptoTermsData

