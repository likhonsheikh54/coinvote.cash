import type React from "react"
export default function CoinByIdLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}

