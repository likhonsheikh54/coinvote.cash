"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { getTopCoins, voteCoin } from "@/lib/actions"
import { formatNumber, getColorForChange } from "@/lib/coingecko-api"

interface Coin {
  id: string
  name: string
  symbol: string
  image: string
  current_price: number
  price_change_percentage_24h: number
  market_cap: number
  total_volume: number
  circulating_supply: number
  last_updated: string
  votes: number
}

export default function CoinTable({ initialCoins }: { initialCoins?: Coin[] }) {
  const [activeTab, setActiveTab] = useState("top")
  const [currentPage, setCurrentPage] = useState(1)
  const [coins, setCoins] = useState<Coin[]>(initialCoins || [])
  const [loading, setLoading] = useState(!initialCoins)
  const [voting, setVoting] = useState<Record<string, boolean>>({})

  const itemsPerPage = 10
  const totalPages = Math.ceil(coins.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const displayedCoins = coins.slice(startIndex, startIndex + itemsPerPage)

  useEffect(() => {
    if (!initialCoins) {
      async function fetchCoins() {
        setLoading(true)
        const result = await getTopCoins()
        if (result.success) {
          setCoins(result.data)
        }
        setLoading(false)
      }

      fetchCoins()
    }
  }, [initialCoins])

  const handleVote = async (id: string) => {
    setVoting((prev) => ({ ...prev, [id]: true }))
    await voteCoin(id)

    // Update the local state to reflect the vote
    setCoins((prev) => prev.map((coin) => (coin.id === id ? { ...coin, votes: coin.votes + 1 } : coin)))

    setVoting((prev) => ({ ...prev, [id]: false }))
  }

  if (loading) {
    return (
      <div className="bg-[#0D1217] rounded-lg border border-gray-800 p-8 flex justify-center items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#FFDD33]"></div>
      </div>
    )
  }

  // Function to format time since last update
  const formatTimeSince = (dateString: string) => {
    const now = new Date()
    const updated = new Date(dateString)
    const diffMs = now.getTime() - updated.getTime()
    const diffMins = Math.floor(diffMs / 60000)

    if (diffMins < 1) return "Just now"
    if (diffMins < 60) return `${diffMins}m ago`

    const diffHours = Math.floor(diffMins / 60)
    if (diffHours < 24) return `${diffHours}h ago`

    const diffDays = Math.floor(diffHours / 24)
    return `${diffDays}d ago`
  }

  return (
    <div className="bg-[#0D1217] rounded-lg border border-gray-800 overflow-hidden">
      <div className="flex border-b border-gray-800">
        <button
          className={`px-6 py-3 text-sm font-medium ${activeTab === "top" ? "text-[#FFDD33] border-b-2 border-[#FFDD33]" : "text-gray-400"}`}
          onClick={() => setActiveTab("top")}
        >
          Top
        </button>
        <button
          className={`px-6 py-3 text-sm font-medium ${activeTab === "trending" ? "text-[#FFDD33] border-b-2 border-[#FFDD33]" : "text-gray-400"}`}
          onClick={() => setActiveTab("trending")}
        >
          Trending
        </button>
        <button
          className={`px-6 py-3 text-sm font-medium ${activeTab === "new" ? "text-[#FFDD33] border-b-2 border-[#FFDD33]" : "text-gray-400"}`}
          onClick={() => setActiveTab("new")}
        >
          New
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-left text-xs text-gray-400 border-b border-gray-800">
              <th className="px-6 py-3 w-12">#</th>
              <th className="px-6 py-3">Coin</th>
              <th className="px-6 py-3">Price</th>
              <th className="px-6 py-3">24h</th>
              <th className="px-6 py-3">Market Cap</th>
              <th className="px-6 py-3">Volume (24h)</th>
              <th className="px-6 py-3">Last Updated</th>
              <th className="px-6 py-3">Vote</th>
            </tr>
          </thead>
          <tbody>
            {displayedCoins.map((coin, index) => (
              <tr key={coin.id} className="border-b border-gray-800 hover:bg-gray-900/50">
                <td className="px-6 py-4 text-sm">{startIndex + index + 1}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <Image
                      src={coin.image || "/placeholder.svg"}
                      alt={coin.name}
                      width={24}
                      height={24}
                      className="rounded-full"
                      onError={(e) => {
                        // Fallback to placeholder if logo not found
                        ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=24&width=24"
                      }}
                    />
                    <div>
                      <Link href={`/coins/${coin.id}`} className="font-medium hover:text-[#FFDD33]">
                        {coin.name}
                      </Link>
                      <div className="text-xs text-gray-400">{coin.symbol.toUpperCase()}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 font-medium">
                  $
                  {coin.current_price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 })}
                </td>
                <td className={`px-6 py-4 ${getColorForChange(coin.price_change_percentage_24h)}`}>
                  {coin.price_change_percentage_24h >= 0 ? "+" : ""}
                  {coin.price_change_percentage_24h.toFixed(2)}%
                </td>
                <td className="px-6 py-4">{formatNumber(coin.market_cap)}</td>
                <td className="px-6 py-4">{formatNumber(coin.total_volume)}</td>
                <td className="px-6 py-4 text-sm">{formatTimeSince(coin.last_updated)}</td>
                <td className="px-6 py-4">
                  <Button
                    onClick={() => handleVote(coin.id)}
                    size="sm"
                    className="bg-[#FFDD33] text-black hover:bg-[#FFDD33]/90 w-16"
                    disabled={voting[coin.id]}
                  >
                    {voting[coin.id] ? "..." : coin.votes}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-center gap-1 p-4 border-t border-gray-800">
        <Button
          variant="outline"
          size="icon"
          className="w-8 h-8 text-gray-400 border-gray-700"
          onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
          disabled={currentPage === 1}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => (
          <Button
            key={i + 1}
            variant={currentPage === i + 1 ? "default" : "outline"}
            size="icon"
            className={`w-8 h-8 ${
              currentPage === i + 1 ? "bg-[#FFDD33] text-black hover:bg-[#FFDD33]/90" : "text-gray-400 border-gray-700"
            }`}
            onClick={() => setCurrentPage(i + 1)}
          >
            {i + 1}
          </Button>
        ))}

        <Button
          variant="outline"
          size="icon"
          className="w-8 h-8 text-gray-400 border-gray-700"
          onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
          disabled={currentPage === totalPages}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

