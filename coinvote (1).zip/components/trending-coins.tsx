"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronRight, Flame } from "lucide-react"
import { getTrendingCoinsList } from "@/lib/actions"

interface TrendingCoin {
  id: string
  name: string
  symbol: string
  image: string
  market_cap_rank: number
  price_btc: number
  votes: number
}

export default function TrendingCoins() {
  const [coins, setCoins] = useState<TrendingCoin[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchTrendingCoins() {
      setLoading(true)
      const result = await getTrendingCoinsList()
      if (result.success) {
        setCoins(result.data)
      }
      setLoading(false)
    }

    fetchTrendingCoins()
  }, [])

  if (loading) {
    return (
      <div className="bg-[#0D1217] rounded-lg border border-gray-800 p-8 flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-[#FFDD33]"></div>
      </div>
    )
  }

  return (
    <div className="bg-[#0D1217] rounded-lg border border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
        <div className="flex items-center gap-2">
          <Flame className="h-4 w-4 text-[#FFDD33]" />
          <h3 className="font-medium">Trending</h3>
        </div>
        <Link href="/ranking/trending" className="text-xs text-gray-400 hover:text-[#FFDD33] flex items-center">
          More <ChevronRight className="h-3 w-3 ml-1" />
        </Link>
      </div>

      <div className="divide-y divide-gray-800">
        {coins.map((coin) => (
          <div key={coin.id} className="px-4 py-3 hover:bg-gray-900/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Image
                  src={coin.image || "/placeholder.svg"}
                  alt={coin.name}
                  width={24}
                  height={24}
                  className="rounded-full"
                  onError={(e) => {
                    // Fallback to placeholder if logo not found
                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=24&width=24"
                  }}
                />
                <div>
                  <Link href={`/coins/${coin.id}`} className="font-medium hover:text-[#FFDD33]">
                    {coin.name}
                  </Link>
                  <div className="text-xs text-gray-400">{coin.symbol}</div>
                </div>
              </div>
              <div className="text-sm">
                <div className="text-right">#{coin.market_cap_rank || "N/A"}</div>
                <div className="text-xs text-gray-400">{coin.votes} votes</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

