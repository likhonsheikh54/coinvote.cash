import LoginPageClient from "./LoginPageClient"

export const metadata = {
  title: "Login | Coinvote.cash",
  description: "Log in to your Coinvote.cash account to manage your profile and votes.",
}

export default function LoginPage() {
  return <LoginPageClient />
}

