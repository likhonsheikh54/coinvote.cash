import { getIndexNowKeyFileContent } from "@/lib/indexnow-api"

export async function GET() {
  return new Response(getIndexNowKeyFileContent(), {
    headers: {
      "Content-Type": "text/plain",
    },
  })
}

