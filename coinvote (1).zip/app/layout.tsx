import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Header from "@/components/header"
import Footer from "@/components/footer"
import TickerWidget from "@/components/ticker-widget"
import FirebaseProvider from "@/components/firebase-provider"
import Script from "next/script"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: {
    default: "Coinvote.cash - Cryptocurrency Voting Platform",
    template: "%s | Coinvote.cash",
  },
  description:
    "Coinvote is a leading cryptocurrency aggregation platform, spotlighting early-stage tokens, NFTs, and meme coins with high potential.",
  keywords: [
    "cryptocurrency",
    "crypto voting",
    "coin ranking",
    "blockchain",
    "bitcoin",
    "ethereum",
    "NFT",
    "ICO",
    "airdrop",
  ],
  authors: [{ name: "Coinvote Team" }],
  creator: "Coinvote.cash",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://coinvote.cash",
    siteName: "Coinvote.cash",
    title: "Coinvote.cash - Cryptocurrency Voting Platform",
    description: "Discover and vote for the best cryptocurrencies",
    images: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/OIP%20%2832%29.jpg-LYzwf2vkqDIrttgY8IJ1gV3vS6EjK1.jpeg",
        width: 1200,
        height: 630,
        alt: "Coinvote.cash - Find New Cryptos Early",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Coinvote.cash - Cryptocurrency Voting Platform",
    description: "Discover and vote for the best cryptocurrencies",
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/OIP%20%2832%29.jpg-LYzwf2vkqDIrttgY8IJ1gV3vS6EjK1.jpeg",
    ],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <FirebaseProvider>
            <div className="min-h-screen bg-moon-night text-white flex flex-col">
              <Header />
              <TickerWidget />
              <main className="flex-grow">{children}</main>
              <Footer />
            </div>
          </FirebaseProvider>
        </ThemeProvider>

        {/* Firebase Scripts */}
        <Script type="module" strategy="afterInteractive">
          {`
            // Import the functions you need from the SDKs you need
            import { initializeApp } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
            
            // Your web app's Firebase configuration
            const firebaseConfig = {
              apiKey: "AIzaSyAkQ02G0lYQojNWEKDoioIA4TUt8vTdLOM",
              authDomain: "flashusdt.firebaseapp.com",
              projectId: "flashusdt",
              storageBucket: "flashusdt.firebasestorage.app",
              messagingSenderId: "1056011053890",
              appId: "1:1056011053890:web:83ad134de3bf7a1b3f36db"
            };
            
            // Initialize Firebase
            const app = initializeApp(firebaseConfig);
          `}
        </Script>

        {/* JSON-LD Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              name: "Coinvote.cash",
              url: "https://coinvote.cash",
              potentialAction: {
                "@type": "SearchAction",
                target: "https://coinvote.cash/search?q={search_term_string}",
                "query-input": "required name=search_term_string",
              },
              description:
                "Coinvote is a leading cryptocurrency aggregation platform, spotlighting early-stage tokens, NFTs, and meme coins with high potential.",
            }),
          }}
        />
      </body>
    </html>
  )
}



import './globals.css'